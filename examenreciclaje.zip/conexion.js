import { Connection } from 'tedious';

const config = {
    server: 'LAPTOP-3FIRK58J',
    authentication: {
        type: 'default',
        options: {
            userName: "ejemplo",
            password: "1234"
        }
    },
    options: {
        port: 1433,
        database: 'yoreciclo',
        trustServerCertificate: true
    }
}


const connection = new Connection(config);

connection.connect();

connection.on('connect', (err) => {
    if (err) {
        console.log("Error al conectarse a la base de datos:", err); 
    } else {
        executeStatement();
    }
});

function executeStatement() {
    console.log("Conectado a la base de datos");
}
